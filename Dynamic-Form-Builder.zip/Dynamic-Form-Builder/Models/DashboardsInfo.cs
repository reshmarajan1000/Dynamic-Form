﻿using System;
using System.Collections.Generic;

namespace Dynamic_User_Defined_Dashboards.Models
{
    public partial class DashboardsInfo
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int TemplateId { get; set; }
    }
}
