﻿using System;
using System.Collections.Generic;

namespace Dynamic_User_Defined_Dashboards.Models
{
    public partial class Templates
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int ElementsCount { get; set; }
    }
}
