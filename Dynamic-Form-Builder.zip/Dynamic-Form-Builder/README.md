# Dynamic-Form

Required SDK: .Net Core 2.3
DataBase : Mysql

